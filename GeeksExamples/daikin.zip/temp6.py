def number_decorator(nums):

    nums = list(map(lambda x: x+3, nums))

    def inside(func):

        def wrapper(*args, **kwargs):

            nums = list(map(lambda x: x+2, func(*args)))

            return nums

        return wrapper

    return inside


def number_fetcher(nums):

    return [x for x in range(1, 10)]


print(number_decorator([1, 2, 3, 4, 5])(number_fetcher)([6, 7, 8, 9, 10]))
