class Insect:
    legs = 6

    def __str__(self):
        legs = 4
        return legs

    def __init__(self):
        self.legs = 8


i = Insect()
print(i.legs)
