def foo(num1):

    num3 = 4

    def bar(num2):

        def delt(num3):

            print(num1-num2+num3)

        return delt(5)

    return bar


ans = foo(7)

ans(3)
