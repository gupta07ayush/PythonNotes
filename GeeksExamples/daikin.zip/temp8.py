def gen(mystr):
    for i in mystr:
        yield i


def text(mytext):
    for i in mytext:
        yield i*2


mystr = 'abcde'
print(''.join(text(gen(mystr))))
