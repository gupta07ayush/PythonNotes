list1 = [1, 2, 3, 1, 4, 6, 73, 2, 1, 44]
new = set(list1)
new.pop()
new.pop()
print(list(new))
