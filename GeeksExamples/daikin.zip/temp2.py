import re

mydata = "Hockey is national sport of the nation"

pattern1 = r'H.*y'

pattern2 = r'n.+l'


if re.match(pattern1, mydata):

    mydata = re.sub(pattern1, "Cricket", mydata)

if re.findall(pattern2, mydata):

    mydata = re.sub(pattern2, "favorite", mydata)

    print(mydata)
