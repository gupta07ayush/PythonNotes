def my_decorator(func):

    num2 = 10


def wrapper(*args, **kwargs):
    ans = num2+func(*args)

    return wrapper


@my_decorator
def central(num1):

    return num1

    print(central(2))
